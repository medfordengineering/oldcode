/* -------------------------------------------------------------
Machine Science API
 
(c) Copyright Machine Science, 2012.  All rights reserved

Version Date: Mon Oct 25 11:03:19 EDT 2010
-----------------------------------------------------------------
============================================================== */
#ifndef _MASTERMOD_H_
#define _MASTERMOD_H_

#include <machinescience.h>

#endif

